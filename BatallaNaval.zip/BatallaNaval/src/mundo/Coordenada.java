/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mundo;

/**
 *
 * @author sala2
 */
public class Coordenada {
        //Atributos
    private final int FILA;
    private final int COLUMNA;
    
    //constructor
    public Coordenada(String fila, int columna){
        
    }
    
    //getters y setters
    public int getFila(){
    }
    
    public int getColumna(){
    }
    //metodos funcionales
    public boolean validarCoordenada(){
        
    }
}

